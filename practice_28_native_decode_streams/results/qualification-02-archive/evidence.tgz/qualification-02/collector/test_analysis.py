import unittest
from types import SimpleNamespace

from common import Bindings, disjoint, overlap, union


class RecoveryTests(unittest.TestCase):
    def test_exception_restores_exact_reference(self):
        old = object()
        state = SimpleNamespace(value=old)
        with self.assertRaisesRegex(RuntimeError, "injected"):
            with Bindings([(state, "value", object()), (state, "temporary", 1)]):
                raise RuntimeError("injected")
        self.assertIs(state.value, old)
        self.assertFalse(hasattr(state, "temporary"))

    def test_nested_binding(self):
        state = SimpleNamespace(value=1)
        with Bindings([(state, "value", 2)]):
            with Bindings([(state, "value", 3)]):
                self.assertEqual(state.value, 3)
            self.assertEqual(state.value, 2)
        self.assertEqual(state.value, 1)

    def test_inherited_attribute_restored_without_shadow(self):
        class Base:
            value = object()
        class Child(Base):
            pass
        with Bindings([(Child, "value", 42)]):
            self.assertEqual(Child.value, 42)
        self.assertNotIn("value", vars(Child))
        self.assertIs(Child.value, Base.value)


class AnalysisTests(unittest.TestCase):
    def test_overlap_is_not_envelope_overlap(self):
        self.assertEqual(overlap([(0, 1), (9, 10)], [(2, 8)]), 0)
        self.assertEqual(overlap([(0, 5), (2, 6)], [(3, 7)]), 3)

    def test_negative_interval_rejected(self):
        with self.assertRaises(ValueError):
            union([(2, 1)])

    def test_storage_alias_detected(self):
        self.assertTrue(disjoint([('A', 'kv', 0, 10), ('B', 'out', 9, 12)]))
        self.assertFalse(disjoint([('A', 'kv', 0, 10), ('B', 'out', 10, 12)]))


if __name__ == '__main__':
    unittest.main()
