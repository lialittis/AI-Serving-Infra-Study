"""Exact CPU/CANN/CSV and graph identity joins for one pair per trace."""
import argparse
from collections import defaultdict
import csv
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import sys

from common import save, overlap, union


def helpers():
    repo = next(p for p in Path(__file__).resolve().parents if (p / 'practice_26_decode_utilization/analyze.py').exists())
    spec = importlib.util.spec_from_file_location('p26_evidence_helpers', repo / 'practice_26_decode_utilization/analyze.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(path.read_text(), parse_float=Decimal)


def analyze_trial(root, run):
    h = helpers()
    number, end, only, require = h.number, h.end, h.only, h.require
    events = read(only(root.rglob('trace_view.json'), 'one trace'))
    if isinstance(events, dict):
        events = events['traceEvents']
    with only(root.rglob('kernel_details.csv'), 'one CSV').open() as f:
        rows = list(csv.DictReader(f))
    records = {r['label']: r for r in read(root / 'observations.json')}
    scopes = {e['name']: e for e in events if e.get('ph') == 'X' and e.get('name') in records}
    require(set(scopes) == set(records), 'missing scope')
    points, starts, finishes = defaultdict(list), defaultdict(list), defaultdict(list)
    def point(e):
        return e['pid'], e['tid'], number(e['ts'])
    for index, event in enumerate(events):
        phase = event.get('ph')
        if phase == 'X':
            points[point(event)].append((index, event))
        elif phase == 's':
            starts[event.get('cat'), str(event['id'])].append(event)
        elif phase == 'f':
            finishes[(event.get('cat'),) + point(event)].append(event)

    queues = []
    for event in events:
        if event.get('ph') == 'X' and event.get('cat') == 'dequeue':
            for finish in finishes[('async_task_queue',) + point(event)]:
                queues.append((event, only(starts['async_task_queue', str(finish['id'])], 'enqueue'), str(finish['id'])))
    def source(event, category, native=None):
        fs = finishes[(category,) + point(event)]
        if not fs:
            return None
        finish = only(fs, 'flow finish')
        ss = starts[category, str(finish['id'])]
        if category == 'async_npu' and len(ss) > 1 and native:
            candidates = [q for q in queues if q[0]['tid'] == native['tid'] and number(q[0]['ts']) <= number(native['ts']) and end(native) <= end(q[0])]
            index, host, _ = h.resolve_colliding_host([only(points[point(s)], 'host') for s in ss], native, candidates)
            return index, host, str(finish['id'])
        index, host = only(points[point(only(ss, 'flow source'))], 'source range')
        return index, host, str(finish['id'])
    def containing(event, native=False):
        tid = event.get('args', {}).get('Thread Id', event['tid']) if native else event['tid']
        matches = [(label, s) for label, s in scopes.items() if s['tid'] == tid and
                   (native or s['pid'] == event['pid']) and number(s['ts']) <= number(event['ts']) and end(event) <= end(s)]
        return min(matches, key=lambda x: number(x[1]['dur']))[0] if matches else None

    models = {}
    for g in read(run / 'graphs.json'):
        dump = read(run / g['path'])
        mid = only({int(d['args']['Model Id']) for d in dump}, 'one model ID')
        require(mid not in models, 'duplicate live model ID')
        models[mid] = dict(graph=g, dump=dump)
    native_replays = defaultdict(list)
    for index, event in enumerate(events):
        if event.get('ph') == 'X' and event.get('name') == 'AscendCL@aclmdlRIExecuteAsync':
            native_replays[str(event['args']['connection_id'])].append((index, event))
    csv_index = defaultdict(list)
    for index, row in enumerate(rows):
        csv_index[row['Name'], row['Stream ID'].strip(), row['Task ID'].strip(), number(row['Start Time(us)'])].append(index)
    tasks, used, by_scope = [], set(), defaultdict(list)
    for index, event in enumerate(events):
        args = event.get('args', {})
        if event.get('ph') != 'X' or 'Task Type' not in args or event['name'] in ('PROFILING_ENABLE', 'PROFILING_DISABLE'):
            continue
        internal = args.get('Model Id') in models
        native = None if internal else source(event, 'HostToDevice')
        if native is None and event['name'] in ('MODEL_EXECUTE', 'NOTIFY_WAIT'):
            ni, ne = only(native_replays[str(args['connection_id'])], 'native replay connection')
            native = ni, ne, 'connection:' + str(args['connection_id'])
        host = None if internal else source(event, 'async_npu', native[1] if native else None)
        label = containing(host[1]) if host else None
        if label is None and native:
            label = containing(native[1], True)
        record = records.get(label, {})
        task = dict(id=index, name=event['name'], stream=str(args['Physic Stream Id']),
                    task_id=str(args['Task Id']), model_id=args.get('Model Id'),
                    start_us=str(event['ts']), end_us=str(end(event)), duration_us=str(event['dur']),
                    role=record.get('role'), scope=label, is_compute=False,
                    host_index=host[0] if host else None, cann_index=native[0] if native else None,
                    host_flow=host[2] if host else None, cann_flow=native[2] if native else None)
        matches = csv_index[event['name'], task['stream'], task['task_id'], number(event['ts'])]
        if matches:
            ci = only(matches, 'CSV identity')
            require(ci not in used, 'duplicate CSV task')
            used.add(ci)
            h.validate_csv(task, rows[ci])
            task.update(is_compute=True, csv_row=ci, counters=rows[ci],
                        block_num=h.core_count(rows[ci]['Block Num']), mix_block_num=h.core_count(rows[ci]['Mix Block Num']))
        tasks.append(task)
        if label:
            by_scope[label].append(task)
    require(len(used) == len(rows), 'CSV coverage')

    for mid, model in models.items():
        records_for_graph = [r for r in records.values() if r['kind'] == 'replay' and r['python_id'] == model['graph']['python_id']]
        records_for_graph.sort(key=lambda r: number(scopes[r['label']]['ts']))
        internal = sorted((t for t in tasks if t['model_id'] == mid), key=lambda t: number(t['start_us']))
        dump = model['dump']
        size = len(dump) + (dump[-1]['args']['Task Type'] != 'NOTIFY_RECORD')
        require(len(internal) == size * len(records_for_graph), 'graph task coverage')
        for index, record in enumerate(records_for_graph):
            boundary = by_scope[record['label']]
            launch = only((t for t in boundary if t['name'] == 'MODEL_EXECUTE'), 'graph launch')
            wait = only((t for t in boundary if t['name'] == 'NOTIFY_WAIT'), 'graph completion')
            require(launch['cann_index'] == wait['cann_index'], 'graph connection mismatch')
            chunk = internal[index * size:(index + 1) * size]
            h.validate_graph_chunk(chunk, dump, launch, wait)
            for task in chunk:
                task.update(role=record['role'], scope=record['label'], replay=record['label'])
    compute = [t for t in tasks if t['is_compute']]
    require(all(t['role'] in ('A', 'B') for t in compute), 'unattributed compute')
    intervals = {role: [(number(t['start_us']), number(t['end_us'])) for t in compute if t['role'] == role] for role in ('A', 'B')}
    require(all(intervals.values()), 'missing branch')
    start = min(a for v in intervals.values() for a, b in v)
    finish = max(b for v in intervals.values() for a, b in v)
    both = overlap(intervals['A'], intervals['B'])
    coverage = sum((b-a for a, b in union(intervals['A'] + intervals['B'])), Decimal(0))
    trial = json.loads((root / 'trial.json').read_text())
    if trial['strategy'] == 'serial':
        require(both == 0, 'serial branch overlap violates control')
    result = dict(trial=trial, compute_tasks=len(compute), stream_ids=sorted({t['stream'] for t in compute}),
                  overlap_us=str(both), compute_union_us=str(coverage), device_compute_span_us=str(finish-start),
                  coverage=float(coverage/(finish-start)), tasks=tasks,
                  cpu_scopes={label: {k: str(s[k]) for k in ('ts', 'dur', 'pid', 'tid')} for label, s in scopes.items()})
    save(root / 'analysis.json', result)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('run', type=Path)
    a = p.parse_args()
    summaries = []
    for path in sorted((a.run / 'trials').iterdir()):
        result = analyze_trial(path, a.run)
        summaries.append({k: v for k, v in result.items() if k not in ('tasks', 'cpu_scopes')})
    save(a.run / 'analysis_summary.json', summaries)


if __name__ == '__main__':
    main()
